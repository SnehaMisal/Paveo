<meta name="description" content="" />
<meta name="keywords" content="">
<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo base_url() ?>assets/images/favicon_1.png" />

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;display=swap"
    rel="stylesheet">

<!-- Icons -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/fonts/boxicons.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/fonts/fontawesome.css" />
<!-- <link rel="stylesheet" href="../../assets/vendor/fonts/flag-icons.css" /> -->

<!-- Core CSS -->
<!-- <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css" class="template-customizer-core-css" /> -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/perfect-scrollbar/perfect-scrollbar.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/quill/katex.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/quill/editor.css" />
<!-- <link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/bootstrap-select/bootstrap-select.css" /> -->

<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/select2/select2.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/daterangepicker/daterangepicker.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/datatables/datatables.bundle.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/bootstrap4-toggle/bootstrap4-toggle.min.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/sweetalert2/sweetalert2.min.css" />
<!-- lightgallery css -->
<link rel="stylesheet" type="text/css"
    href="<?php echo base_url() ?>assets/plugins/lightgallery/css/lightgallery.min.css">
<!--dropify css  -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/plugins/dropify/css/dropify.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/image_upload/imageuploadify.min.css">

<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/core.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/demo.css" />
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/theme-default.css"
    class="template-customizer-theme-css" />

<!-- Vendors CSS -->
<!-- <link rel="stylesheet" href="../../assets/vendor/libs/typeahead-js/typeahead.css" /> -->
<!-- <link rel="stylesheet" href="../../assets/vendor/libs/apex-charts/apex-charts.css" /> -->

<!-- Page CSS -->