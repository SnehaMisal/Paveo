

    <!-- Core JS -->
  <!-- build:js assets/vendor/js/core.js -->
  <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
  <!-- <script src="../../assets/vendor/libs/popper/popper.js"></script> -->
  <script src="<?php echo base_url() ?>assets/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url() ?>assets/js/config.js"></script>
  <script src="<?php echo base_url() ?>assets/plugins/perfect-scrollbar/perfect-scrollbar.js"></script>
  
  <!-- <script src="../../assets/vendor/libs/hammer/hammer.js"></script> -->
  <!-- <script src="../../assets/vendor/libs/i18n/i18n.js"></script> -->
  <!-- <script src="../../assets/vendor/libs/typeahead-js/typeahead.js"></script> -->
  
  <script src="<?php echo base_url() ?>assets/js/menu.js"></script>
  <!-- endbuild -->

  <!-- Vendors JS -->
  <!-- <script src="../../assets/vendor/libs/apex-charts/apexcharts.js"></script> -->

  <!-- Main JS -->
 

  <!-- Page JS -->
  <!-- <script src="../../assets/js/dashboards-analytics.js"></script> -->
  <!-- Helpers -->
  <script src="<?php echo base_url() ?>assets/js/helpers.js"></script>
      <!--!  & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <!-- <script src="<?php echo base_url() ?>assets/js/template-customizer.js"></script> -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo base_url() ?>assets/plugins/quill/katex.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/quill/quill.js"></script>
    <!-- <script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/bootstrap-select.js"></script> -->
    <script src="<?php echo base_url() ?>assets/plugins/select2/select2.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/daterangepicker/moment.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/datatables/datatables.bundle.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap4-toggle/bootstrap4-toggle.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
<!--lightgallery js  -->
<script src="<?php echo base_url() ?>assets/plugins/lightgallery/js/lightgallery-all.min.js"></script>
<!-- dropify js -->
<script src="<?php echo base_url() ?>assets/plugins/dropify/js/dropify.js"></script>  
<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/image_upload/imageuploadify.min.js">
    </script>  
    <script src="<?php echo base_url() ?>assets/plugins/apex-chart/apex-chart.js"></script>
<script src="<?php echo base_url() ?>assets/js/main.js"></script>
    <script src="<?php echo base_url() ?>assets/js/script.js"></script>